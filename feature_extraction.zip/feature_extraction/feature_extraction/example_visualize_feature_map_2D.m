function [] = example_visualize_feature_map_2D(varargin)

%example function for visualizing feature maps.
% does not work though without edits

% clear
% close all
% clc

%*****************************MODIFY THIS*************%
% repopath = '\\csehomes/csehome$\jta35\My Documents\MATLAB\Research\Madabhushi\REPO\'; %don't forget the last "\"
% 
% ptdir = '\\csehomes\csehome$\jta35\My Documents\MATLAB\';

%****************************************************%

% if exist([repopath])~=7
%     error('manually edit REPOPATH variable in feature_map_2D.m to get CCIPD repository into your path!')
% end

% Load patient data
%% user info
pt = input('Enter patient number: ');
% opt = input('Pick Feature either by Intensity (Enter 1) or Statistic(Enter 2): ');
opt = 1;
if opt == 1
f = input('Enter feature ID: '); %i.e. 29, ENTER
load([ptdir,'case_',int2str(pt),'_featinfo.mat'],'featints'); 
ints = featints{f};
% elseif opt == 2
% f = input('Enter feature statistic ID (1-1911): ');
% [~, c] = ind2sub([13 313], f);
% load([patients(pt).directory,featfile],'featints'); 
% ints = cell2mat(featints(c));
else
    error('Invalid option.');
end

%% load patient data
fprintf('\tLoading patient data\n');

addpath('\\csehomes\csehome$\jta35\My Documents\MATLAB\Research\Madabhushi\REPO\repo_jacob\General');

vol = cast(mha_read_volume(mha_read_header([ptdir,'case_',int2str(pt),'.mha'])),'double');
mask = cast(mha_read_volume(mha_read_header([ptdir,'case_',int2str(pt),'-label.mha'])),'double');

% %only include cancer mask -- GENERAL PURPOSES
% mask(mask ~= 1) = 0;

% include all relevant masks -- FOR UH_RECTAL_RADIOLOGY DATASET
labels = [1];%fat
mask(mask==labels(1)) = 1;
mask(mask~=1) = 0;

%% create feature volume
fprintf('\tGenerating feature volume\n');

addpath([repopath,'repo_jacob/General']);
featvol = createFeatVol(ints,mask);
rmpath([repopath,'repo_jacob/General']);

%Display map
fprintf('\tDisplaying Overlaid Map\n')
my4DMap(vol,featvol,mask,repopath);

end

%GUI objects
function my4DMap(vol,map_vol,mask,repopath)

    figure('Color','white');
       
    begin_index = find(mask==1,1,'first');
    end_index = find(mask==1,1,'last');

    [~,~,begin_slice] = ind2sub(size(mask),begin_index);
    [~,~,end_slice] = ind2sub(size(mask),end_index);
    slice = round((end_slice+begin_slice)/2);
    
    slider = uicontrol('Style', 'slider',...
       'Max',size(vol,3),'Min',1,...
       'Units', 'normalized', ...
       'Position', [.25 .005 .4 .04],...
       'SliderStep', [1/(size(vol,3)-1) 1/(size(vol,3)-1)], ...
       'Value', slice, ...
       'Callback', @move_slider);
    
    text_box = uicontrol('Style', 'text',...
       'Units', 'normalized', ...
       'Position', [.675 .006 .04 .04],...
       'String', num2str(slice));
   
    set(gcf,'UserData',map_vol);
    showmap(slice, vol, map_vol, mask,repopath);



%callback to slider
function move_slider(~,~)
mapdata = get(gcf,'UserData');
slice = round(get(gcbo,'Value'));
set(gcbo,'Value',slice);
set(text_box,'String',num2str(slice));
save_xlim = xlim;
save_ylim = ylim;
showmap(slice,vol,mapdata,mask,repopath);
xlim(save_xlim);
ylim(save_ylim);
end

end

%where the images are displayed 
function showmap(slice,origdata,mapdata,mask,repopath)

       %----original-----%
    subplot(1,2,1)
    addpath([repopath,'repo_matlab\images']);
    addpath([repopath,'repo_satish\general']);
    maskslice = transpose(mask(:,:,slice));
    [dx,dy] = gradient(maskslice);
    edgei=sqrt(dx.^2+dy.^2);
    edgei=edgei~=0;
    imagesc(rgbmaskrgb(rescale(transpose(origdata(:,:,slice))),edgei,[0 1 0]));colormap gray; axis off;
    axis image
    %     imagesc(transpose(origdata(:,:,slice)));colormap(gray);axis off; %previously used
    title([ 'slice ' num2str(slice) ' of ' num2str(size(origdata,3))])

    %----overlay------%
    subplot(1,2,2);
    baseslice = transpose(origdata(:,:,slice));
    heatmapslice = transpose(mapdata(:,:,slice));
   
    baseslice = baseslice/max(baseslice(:));
    rgbslice = baseslice(:,:,[1 1 1]);

    maskslice = transpose(mask(:,:,slice));
    bwROIlocations = (maskslice ~= 0);
    g = imagesc(heatmapslice);colormap(gca,'jet');
    %caxis([0 1]);
    colorbar;
%     g = imagesc(heatmapslice);colormap(gca,'gray'); %never again.

    alpha(g,1); 
    hold on; h = imagesc(rgbslice);
    set(h,'AlphaData',~bwROIlocations);
    axis image
    
    rmpath([repopath,'repo_matlab\images']);
    rmpath([repopath,'repo_satish\general']);
      
    axis off;
    % 
    % colorbar(jet(256));
    % caxis([0 250])
end

