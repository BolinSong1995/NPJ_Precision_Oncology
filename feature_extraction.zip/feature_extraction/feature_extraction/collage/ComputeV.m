function V = SVV(mat)
[U, S, V] = svd(mat);
end