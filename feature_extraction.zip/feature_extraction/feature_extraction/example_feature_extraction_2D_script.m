%% example_feature_extraction_2D_script
% Jacob Antunes 
% April 5, 2017

%% About
% extract 2D features from patient data
% framework can be easily adapted to other datasets
% see extract2DFeatureInfo.m

%% Setup
clear;clc;close all;

codedir = 'Z:\home\axs1330\KRAS\KRAS_Code\'; %where is this code? %don't forget "\";

volname = 'pre_ax.mha'; 
maskname = 'pre_ax_label.mha';
savename = 'pre_ax_2D_feat_info'; %save the texture feature information (intensity values and statististics)

% Load patient information array
load([codedir, 'patients.mat'],'patients');

%% Run Feature extraction Code

for i = 1:length(patients)
   
    ptpath = patients(i).directory;
    fprintf('\nPatient #%i(%s)\n',i,ptpath(end-12:end-1));
    
    if exist([ptpath,volname],'file') ~= 2 || exist([ptpath,maskname],'file') ~= 2
        fprintf('\tMissing %s or %s! \n',volname,maskname);
    else
        %load patient data
        fprintf('\tloading data\n');
        vol = cast(mha_read_volume(mha_read_header([ptpath,volname])),'double');
        mask = cast(mha_read_volume(mha_read_header([ptpath,maskname])),'double');
        
        %get middle 2D slice
        ind = find(mask1==1,1,'first'); %find best occurence (index) where cancer mask is drawn
        [~,~,slice] = ind2sub(size(mask1),ind); %get slice number where the best cancer mask is drawn
        
        img = vol(:,:,slice);
        mask = mask(:,:,slice);
        
        %crop our image and mask
        [img, mask] = boundingBox(img,mask,5);
        
        %look at just mask values of ROIs
        labels = [1 7];%tumor healthy
        mask(mask==labels(1) | mask==labels(2)) = 1;
        mask(mask~=1) = 0;
        
    %call feature extraction code
        if (exist([ptpath,savename,'.mat'],'file')~=2) %if feature stats have not yet been computed, do it!
            fprintf('\tCalling Feature Extraction Code\n');
            [featints, featnames, featstats, statnames] = extract2DFeatureInfo(img,mask);
            fprintf('Saving featstats...');
            save([ptpath,savename,'.mat'],'featints','featnames','featstats','statnames');
            fprintf('Done.\n');
        else
            fprintf('\tFeature stats have previously been extracted.\n');
        end 
    end
    
    clear  featints featnames featstats statnames ptpath vol img mask; %reset for next patient
end


%%
fprintf('***COMPLETE***\n')



