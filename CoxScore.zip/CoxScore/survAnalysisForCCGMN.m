[num,txt,raw] = xlsread('ccf_data_graph.xlsx');
header = txt(1,:);
txt(1,:) = [];
dfs_m = num(:,3);
dfs_e = num(:,4);
fts = num(:, 6:end);

indices=randperm(275);
tr_indices = indices(1:100);
te_indices = setdiff(1:275, tr_indices)';
tr_fts = fts(tr_indices, :);
tr_dfs_e = dfs_e(tr_indices, :);
tr_dfs_m = dfs_m(tr_indices, :);
te_fts = fts(te_indices, :);
te_dfs_e = dfs_e(te_indices, :);
te_dfs_m = dfs_m(te_indices, :);

[surv_significance, risk_threshold, beta, cur_selected_idx, num_top_feats] = surv_train(tr_fts,tr_dfs_m*30.5,~tr_dfs_e);

addpath('.\aebergl-MatSurv-d0f1877');
rs_train=tr_fts(:,cur_selected_idx)*beta;
% figure;bar(sort(rs_train));

% check the KM curve for training data
opt_T=median(rs_train);
labels_pred=logical(rs_train>opt_T);
groupvar=[];
for i=1:length(logical(labels_pred))
    if labels_pred(i)==1
        groupvar{i}='high risk';
    else
        groupvar{i}='low risk';
    end
end
optionsKM.NoPlot=0;
idx_survival_usable=~((tr_dfs_m==0)| isnan(tr_dfs_m)|(tr_dfs_m>100));
[opt_p,~,opt_stats]=MatSurv(tr_dfs_m(idx_survival_usable), logical(tr_dfs_e(idx_survival_usable)), groupvar(idx_survival_usable),'Xstep',10,'Title','10 years survival in training set',optionsKM);

%% %%%% F feed the validation data into the model and do analysis
%data_cLoCoM_LUAD_SC_validation is the feature data from validation set
idx_survival_usable_te=~((te_dfs_m==0)| isnan(te_dfs_m));%|(te_dfs_m>100)
rs_val=te_fts(idx_survival_usable_te,cur_selected_idx)*beta;
figure;subplot(2,1,1);bar(sort(rs_train)); xlabel('patient number/index in trainig cohort'); ylabel('image based risk score in trainig cohort');
subplot(2,1,2);bar(sort(rs_val));xlabel('patient number/index in validation cohort');ylabel('image based risk score in validation cohort');
survival_time_val = te_dfs_m(idx_survival_usable_te);
survival_censor_val = te_dfs_e(idx_survival_usable_te);
% set(gcf,'FontSize',16);

labels_pred=logical(rs_val>opt_T);
groupvar=[];
for i=1:length(logical(labels_pred))
    if labels_pred(i)==1
        groupvar{i}='high risk';
    else
        groupvar{i}='low risk';
    end
end
optionsKM.NoPlot=0;
% kick out the ones with survival time =0 
idx_survival_usable=~((survival_time_val==0)| isnan(survival_time_val)|(survival_time_val>120));
[opt_p,~,opt_stats]=MatSurv(survival_time_val(idx_survival_usable), logical(survival_censor_val(idx_survival_usable)), groupvar(idx_survival_usable),'Xstep',10,'Title','10-years survival in validation set',optionsKM);





