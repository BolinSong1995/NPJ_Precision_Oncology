function [labels_pred,rs_val] = surv_test(test_data, beta, cur_selected_idx, surv_days_test, censor_test, risk_threshold)
%Testing script for survival analysis
% indentify threshold and beta using surv_train
% Cheng Lu (10/27)

rs_val=test_data(:,cur_selected_idx)*beta;
%figure;subplot(2,1,1);bar(sort(rs_train)); xlabel('patient number/index in trainig cohort'); ylabel('image based risk score in trainig cohort');
%subplot(2,1,2);bar(sort(rs_val));xlabel('patient number/index in validation cohort');ylabel('image based risk score in validation cohort');
% set(gcf,'FontSize',16);


labels_pred=logical(rs_val>risk_threshold);
% groupvar=[];
% for i=1:length(logical(labels_pred))
%     if labels_pred(i)==1
%         groupvar{i}='high risk';
%     else
%         groupvar{i}='low risk';
%     end
% end
% optionsKM.NoPlot=0;
% group1=find(labels_pred);
% group2=find(~labels_pred);
% [surv_significance_test, HR]=logrank([surv_days_test(group1) censor_test(group1)],[surv_days_test(group2) censor_test(group2)],0.05,0);

end

